#include "sdsl/construct_config.hpp"

namespace sdsl
{

byte_sa_algo_type construct_config::byte_algo_sa = LIBDIVSUFSORT;

}
