python makeMakefile.py

