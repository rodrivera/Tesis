- This program uses the open source graph drawing framework OGDF v2007.11. You can find it here: www.ogdf.net.

- Please include "ogdf.lib" in the project and built it with Visual Studio 2008.

- Alternatively, you can use the precompiled executable (Windows 32-bit) in the package.

Copyright, Jens M. Schmidt