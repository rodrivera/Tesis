// Copyright (C) 2009 Jens M. Schmidt
#ifdef _MSC_VER
#pragma once
#endif

#ifndef Start_H
#define Start_H


#include <ogdf/basic/Array.h>
#include <ogdf/basic/basic.h>
#include <fstream>
#include <time.h>


namespace ogdf {

}

#endif